package com.myntra.repository;

import org.springframework.data.repository.CrudRepository;

import com.myntra.entity.OtpDetails;

public interface OtpDetailsRepository extends CrudRepository<OtpDetails, String> {

}
