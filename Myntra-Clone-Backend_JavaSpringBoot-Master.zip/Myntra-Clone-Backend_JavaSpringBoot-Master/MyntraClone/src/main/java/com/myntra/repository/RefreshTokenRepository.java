package com.myntra.repository;

import org.springframework.data.repository.CrudRepository;
import com.myntra.entity.JwtRefreshToken;
import java.util.Optional;


public interface RefreshTokenRepository extends CrudRepository<JwtRefreshToken, String> {
	Optional<JwtRefreshToken> findByToken(String token);
}
